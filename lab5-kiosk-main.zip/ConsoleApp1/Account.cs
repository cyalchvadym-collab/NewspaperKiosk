namespace NewspaperKioskLab5;

public class Account
{
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";

    public Account() { }

    public Account(string username, string password)
    {
        Username = username ?? "";
        Password = password ?? "";
    }

    public bool IsEmpty() => string.IsNullOrWhiteSpace(Username);
}
