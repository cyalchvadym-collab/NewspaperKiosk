using System.Text.Json;

namespace NewspaperKioskLab5;

public static class FileDataHandler
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public static void Save<T>(string path, List<T> data)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        string json = JsonSerializer.Serialize(data, JsonOptions);
        File.WriteAllText(path, json);
    }

    public static List<T> Load<T>(string path)
    {
        try
        {
            if (!File.Exists(path)) return new List<T>();
            string json = File.ReadAllText(path);
            var data = JsonSerializer.Deserialize<List<T>>(json, JsonOptions);
            return data ?? new List<T>();
        }
        catch
        {
            // якщо файл пошкоджений — не падаємо
            return new List<T>();
        }
    }
}
