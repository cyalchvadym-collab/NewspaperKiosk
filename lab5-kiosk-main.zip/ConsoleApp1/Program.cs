using System.Text;

namespace NewspaperKioskLab5;

class Program
{
    // Адмінські креденшіали
    private const string ADMIN_USERNAME = "admin";
    private const string ADMIN_PASSWORD = "admin123";

    // Файли для збереження (ЛР5: робота з файлами)
    private static readonly string DataDir = Path.Combine(AppContext.BaseDirectory, "data");
    private static readonly string PublicationsFile = Path.Combine(DataDir, "publications.json");
    private static readonly string CustomersFile = Path.Combine(DataDir, "customers.json");
    private static readonly string SellersFile = Path.Combine(DataDir, "sellers.json");

    private static List<Publication> publications = new();
    private static List<Account> customers = new();
    private static List<Account> sellers = new();

    private static UserSession CurrentSession = new();

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        // Завантажуємо дані з файлів
        LoadAll();

        RenderIntro();
        AskRoleAndAuthenticate();
        ShowMainMenu();
    }

    private static void LoadAll()
    {
        publications = FileDataHandler.Load<Publication>(PublicationsFile);
        customers = FileDataHandler.Load<Account>(CustomersFile);
        sellers = FileDataHandler.Load<Account>(SellersFile);
    }

    private static void SaveAll()
    {
        FileDataHandler.Save(PublicationsFile, publications);
        FileDataHandler.Save(CustomersFile, customers);
        FileDataHandler.Save(SellersFile, sellers);
    }

    #region Console helpers

    static int GetIntInput(string prompt = "Введіть число:")
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write(prompt + " ");
        string? input = Console.ReadLine();
        Console.ResetColor();

        if (int.TryParse(input, out int res))
            return res;

        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Ви ввели не ціле число. Спробуйте ще раз.");
        Console.ResetColor();
        return GetIntInput(prompt);
    }

    static double GetDoubleInput(string prompt = "Введіть число:")
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write(prompt + " ");
        string? input = Console.ReadLine();
        Console.ResetColor();

        if (double.TryParse(input, out double res) && res >= 0)
            return res;

        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Невірне значення. Введіть невід'ємне число (можна 0).");
        Console.ResetColor();
        return GetDoubleInput(prompt);
    }

    static string GetStringInput(string prompt = "Введіть текст:")
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write(prompt + " ");
        string? input = Console.ReadLine();
        Console.ResetColor();
        return input ?? "";
    }

    static void RenderIntro()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.DarkGreen;
        Console.WriteLine("===========================================");
        Console.WriteLine("======== КІОСК ГАЗЕТ ТА ЖУРНАЛІВ (ЛР5) ====");
        Console.WriteLine("===========================================");
        Console.ResetColor();
    }

    #endregion

    #region Role & Auth

    static void AskRoleAndAuthenticate()
    {
        while (true)
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Оберіть роль для входу:");
            Console.ResetColor();
            Console.WriteLine("1. Адміністратор");
            Console.WriteLine("2. Покупець");
            Console.WriteLine("3. Продавець");
            Console.WriteLine("4. Вихід");

            int rc = GetIntInput("Виберіть роль (1-4):");

            switch (rc)
            {
                case 1:
                    if (AuthenticateAdmin())
                    {
                        CurrentSession.Role = Role.Admin;
                        CurrentSession.Username = ADMIN_USERNAME;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Успішний вхід як Адміністратор.");
                        Console.ResetColor();
                        return;
                    }
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Невірний логін/пароль для адміністратора.");
                    Console.ResetColor();
                    break;

                case 2:
                    if (AuthenticateAccount(customers, Role.Customer))
                    {
                        CurrentSession.Role = Role.Customer;
                        return;
                    }
                    break;

                case 3:
                    if (AuthenticateAccount(sellers, Role.Seller))
                    {
                        CurrentSession.Role = Role.Seller;
                        return;
                    }
                    break;

                case 4:
                    Console.WriteLine("Бувай!");
                    Environment.Exit(0);
                    break;

                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Невірний вибір ролі. Спробуйте ще раз.");
                    Console.ResetColor();
                    break;
            }
        }
    }

    static bool AuthenticateAdmin()
    {
        Console.WriteLine("\n=== Авторизація: Адміністратор ===");
        string login = GetStringInput("Логін:");
        string pass = GetStringInput("Пароль:");
        return login == ADMIN_USERNAME && pass == ADMIN_PASSWORD;
    }

    static bool AuthenticateAccount(List<Account> list, Role role)
    {
        string roleName = role == Role.Customer ? "Покупець" : "Продавець";

        Console.WriteLine($"\n=== Авторизація: {roleName} ===");
        string login = GetStringInput("Логін:");
        string pass = GetStringInput("Пароль:");

        var acc = list.FirstOrDefault(a => a.Username == login);

        if (acc != null && acc.Password == pass)
        {
            CurrentSession.Username = login;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Успішний вхід як {roleName} ({login}).");
            Console.ResetColor();
            return true;
        }

        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Акаунт не знайдено або невірний пароль.");
        Console.ResetColor();

        Console.WriteLine("Бажаєте зареєструвати новий акаунт? (1 - Так, 0 - Ні)");
        int choice = GetIntInput("Ваш вибір (1/0):");

        if (choice == 1)
        {
            list.Add(new Account(login, pass));
            SaveAll(); // одразу зберігаємо (ЛР5)
            CurrentSession.Username = login;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Акаунт створено як {roleName} ({login}).");
            Console.ResetColor();
            return true;
        }

        return false;
    }

    #endregion

    #region Main Menu

    static void ShowMainMenu()
    {
        while (true)
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Головне меню:");
            Console.ResetColor();
            Console.WriteLine("1. Видання (газети/журнали)");
            Console.WriteLine("2. Покупці");
            Console.WriteLine("3. Продавці");
            Console.WriteLine("4. Замовлення (купівля)");
            Console.WriteLine("5. Збереження даних у файл");
            Console.WriteLine("6. Перезавантажити дані з файлу");
            Console.WriteLine("7. Змінити користувача / Вийти");

            int choice = GetIntInput("Виберіть пункт меню:");

            switch (choice)
            {
                case 1: ShowPublicationsMenu(); break;
                case 2: ShowAccountsMenu(Role.Customer); break;
                case 3: ShowAccountsMenu(Role.Seller); break;
                case 4: ShowOrderMenu(); break;
                case 5:
                    SaveAll();
                    Console.WriteLine("Дані збережено у файли (publications.json / customers.json / sellers.json).");
                    break;
                case 6:
                    LoadAll();
                    Console.WriteLine("Дані перезавантажено з файлів.");
                    break;
                case 7:
                    Console.WriteLine("1. Змінити користувача");
                    Console.WriteLine("2. Вийти");
                    int sub = GetIntInput("Виберіть (1-2):");
                    if (sub == 1)
                    {
                        CurrentSession = new UserSession();
                        RenderIntro();
                        AskRoleAndAuthenticate();
                    }
                    else Environment.Exit(0);
                    break;

                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Невірний вибір.");
                    Console.ResetColor();
                    break;
            }
        }
    }

    #endregion

    #region Publications

    static void ShowPublicationsMenu()
    {
        while (true)
        {
            Console.Clear();
            RenderIntro();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("======= МЕНЮ ВИДАНЬ (ГАЗЕТИ/ЖУРНАЛИ) =======");
            Console.ResetColor();

            Console.WriteLine("1. Переглянути всі видання");
            Console.WriteLine("2. Пошук видання за назвою");
            Console.WriteLine("3. Сортування (за назвою/ціною)");
            Console.WriteLine("4. Статистика (мін/макс/середня ціна)");

            if (CurrentSession.Role == Role.Admin || CurrentSession.Role == Role.Seller)
            {
                Console.WriteLine("5. Додати нове видання");
                Console.WriteLine("6. Видалити видання");
                Console.WriteLine("7. Повернутись у головне меню");
            }
            else
            {
                Console.WriteLine("5. Повернутись у головне меню");
            }

            int ch = GetIntInput("Виберіть дію:");

            if (CurrentSession.Role == Role.Admin || CurrentSession.Role == Role.Seller)
            {
                switch (ch)
                {
                    case 1: PrintAllPublications(); break;
                    case 2: SearchPublication(); break;
                    case 3: SortPublicationsMenu(); break;
                    case 4: PublicationsStatistics(); break;
                    case 5: AddPublication(); break;
                    case 6: DeletePublication(); break;
                    case 7: return;
                    default: Console.WriteLine("Невірний пункт"); break;
                }
            }
            else
            {
                switch (ch)
                {
                    case 1: PrintAllPublications(); break;
                    case 2: SearchPublication(); break;
                    case 3: SortPublicationsMenu(); break;
                    case 4: PublicationsStatistics(); break;
                    case 5: return;
                    default: Console.WriteLine("Невірний пункт"); break;
                }
            }

            Console.WriteLine("\nНатисніть будь-яку клавішу щоб повернутись...");
            Console.ReadKey();
        }
    }

    static void PrintAllPublications()
    {
        Console.WriteLine("\n=== Газети / Журнали ===");

        if (publications.Count == 0)
        {
            Console.WriteLine("Немає жодного видання.");
            return;
        }

        Console.WriteLine("{0,-5}{1,-30}{2,-12}{3,10}", "№", "Назва", "Категорія", "Ціна");
        for (int i = 0; i < publications.Count; i++)
        {
            Console.WriteLine("{0,-5}{1,-30}{2,-12}{3,10}", i + 1, publications[i].Name, publications[i].Category, publications[i].Price);
        }
    }

    static void AddPublication()
    {
        string name = GetStringInput("Введіть назву видання:");
        string cat = GetStringInput("Категорія (газета/журнал):");
        double price = GetDoubleInput("Ціна (грн):");

        publications.Add(new Publication(name, price, cat));
        SaveAll(); // зберігаємо одразу (ЛР5)
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Видання додано та збережено у файл.");
        Console.ResetColor();
    }

    static void DeletePublication()
    {
        PrintAllPublications();
        if (publications.Count == 0) return;

        int idx = GetIntInput("Введіть номер видання для видалення:") - 1;
        if (idx >= 0 && idx < publications.Count)
        {
            publications.RemoveAt(idx);
            SaveAll();
            Console.WriteLine("Видання видалено та зміни збережено.");
        }
        else
        {
            Console.WriteLine("Невірний номер.");
        }
    }

    static void SearchPublication()
    {
        string q = GetStringInput("Введіть частину назви для пошуку:");
        var found = publications
            .Select((p, i) => (p, i))
            .Where(x => x.p.Name.Contains(q, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (found.Count == 0)
        {
            Console.WriteLine("Нічого не знайдено.");
            return;
        }

        foreach (var (p, i) in found)
        {
            Console.WriteLine($"{i + 1}. {p.Name} ({p.Category}) - {p.Price} грн");
        }
    }

    static void SortPublicationsMenu()
    {
        Console.WriteLine("1. Сортування за назвою (А-Я)");
        Console.WriteLine("2. Сортування за ціною (зростання)");
        int ch = GetIntInput("Виберіть тип сортування:");
        switch (ch)
        {
            case 1:
                publications.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                Console.WriteLine("Сортування за назвою виконано.");
                break;
            case 2:
                publications.Sort((a, b) => a.Price.CompareTo(b.Price));
                Console.WriteLine("Сортування за ціною виконано.");
                break;
            default:
                Console.WriteLine("Невірний вибір.");
                break;
        }
    }

    static void PublicationsStatistics()
    {
        if (publications.Count == 0)
        {
            Console.WriteLine("Немає даних для статистики.");
            return;
        }

        double min = publications.Min(p => p.Price);
        double max = publications.Max(p => p.Price);
        double avg = publications.Average(p => p.Price);
        Console.WriteLine($"Кількість видань: {publications.Count}");
        Console.WriteLine($"Мінімальна ціна: {min}");
        Console.WriteLine($"Максимальна ціна: {max}");
        Console.WriteLine($"Середня ціна: {Math.Round(avg, 2)}");
    }

    #endregion

    #region Accounts (Admin only)

    static void ShowAccountsMenu(Role role)
    {
        bool isAdmin = CurrentSession.Role == Role.Admin;
        if (!isAdmin)
        {
            Console.WriteLine("Доступно лише адміністратору.");
            return;
        }

        var list = role == Role.Customer ? customers : sellers;
        string title = role == Role.Customer ? "ПОКУПЦІ" : "ПРОДАВЦІ";

        while (true)
        {
            Console.Clear();
            RenderIntro();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"========= МЕНЮ {title} =========");
            Console.ResetColor();

            Console.WriteLine("1. Переглянути список");
            Console.WriteLine("2. Додати акаунт");
            Console.WriteLine("3. Видалити акаунт");
            Console.WriteLine("4. Повернутись у головне меню");

            int ch = GetIntInput("Виберіть дію:");

            switch (ch)
            {
                case 1:
                    PrintAccounts(list, title);
                    break;
                case 2:
                    AddAccount(list);
                    SaveAll();
                    break;
                case 3:
                    DeleteAccount(list);
                    SaveAll();
                    break;
                case 4: return;
                default: Console.WriteLine("Невірний пункт"); break;
            }

            Console.WriteLine("\nНатисніть будь-яку клавішу...");
            Console.ReadKey();
        }
    }

    static void PrintAccounts(List<Account> list, string title)
    {
        Console.WriteLine($"\n=== {title} ===");
        if (list.Count == 0)
        {
            Console.WriteLine("Список порожній.");
            return;
        }
        Console.WriteLine("{0,-5}{1,-20}", "№", "Логін");
        for (int i = 0; i < list.Count; i++)
        {
            Console.WriteLine("{0,-5}{1,-20}", i + 1, list[i].Username);
        }
    }

    static void AddAccount(List<Account> list)
    {
        string login = GetStringInput("Логін:");
        string pass = GetStringInput("Пароль:");

        if (list.Any(a => a.Username == login))
        {
            Console.WriteLine("Такий логін вже існує.");
            return;
        }

        list.Add(new Account(login, pass));
        Console.WriteLine("Акаунт додано.");
    }

    static void DeleteAccount(List<Account> list)
    {
        if (list.Count == 0)
        {
            Console.WriteLine("Немає кого видаляти.");
            return;
        }
        PrintAccounts(list, "Акаунти");
        int idx = GetIntInput("Введіть номер для видалення:") - 1;
        if (idx >= 0 && idx < list.Count)
        {
            list.RemoveAt(idx);
            Console.WriteLine("Видалено.");
        }
        else
        {
            Console.WriteLine("Невірний номер.");
        }
    }

    #endregion

    #region Orders (Customer/Seller/Admin)

    static void ShowOrderMenu()
    {
        Console.Clear();
        RenderIntro();
        Console.WriteLine("=== Замовлення (купівля) ===\n");

        if (publications.Count == 0)
        {
            Console.WriteLine("Немає доступних видань.");
            return;
        }

        PrintAllPublications();

        Console.WriteLine("\n!!! Увага — можливі знижки залежно від суми покупки !!!\n");

        double total = 0;
        var quantities = new double[publications.Count];

        for (int i = 0; i < publications.Count; i++)
        {
            quantities[i] = GetDoubleInput($"Скільки екземплярів \"{publications[i].Name}\" (0 - не беру): ");
            total += quantities[i] * publications[i].Price;
        }

        double discount = 0;
        if (total > 10000) discount = 30;
        else if (total > 5000) discount = 20;
        else if (total > 2000) discount = 10;

        double discountAmount = Math.Round(total * (discount / 100.0), 2);
        double finalPrice = Math.Round(total - discountAmount, 2);

        Console.ForegroundColor = ConsoleColor.DarkBlue;
        Console.WriteLine("\n=== Підсумок замовлення ===");
        for (int i = 0; i < publications.Count; i++)
        {
            if (quantities[i] > 0)
            {
                Console.WriteLine($"{publications[i].Name}: {quantities[i]} шт., вартість: {quantities[i] * publications[i].Price} грн");
            }
        }
        Console.ResetColor();

        Console.ForegroundColor = ConsoleColor.DarkCyan;
        Console.WriteLine($"\nЗагальна сума без знижки: {total} грн.");
        Console.WriteLine($"Знижка: {discount}% (економія: {discountAmount} грн.)");
        Console.WriteLine($"Сума до оплати: {finalPrice} грн.");
        Console.ResetColor();

        Console.WriteLine("\nДякуємо за покупку в нашому кіоску!");
    }

    #endregion
}
