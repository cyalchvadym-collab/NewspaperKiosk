namespace NewspaperKioskLab5;

public class Publication
{
    public string Name { get; set; } = "";
    public double Price { get; set; } = 0;
    public string Category { get; set; } = ""; // "газета" або "журнал"

    public Publication() { }

    public Publication(string name, double price, string category)
    {
        Name = name ?? "";
        Price = price < 0 ? 0 : price;
        Category = category ?? "";
    }

    public bool IsEmpty() => string.IsNullOrWhiteSpace(Name);
}
