namespace NewspaperKioskLab5;

public enum Role
{
    None,
    Admin,
    Customer,
    Seller
}
