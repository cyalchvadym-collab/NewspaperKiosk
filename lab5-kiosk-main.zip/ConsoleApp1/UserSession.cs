namespace NewspaperKioskLab5;

public class UserSession
{
    public Role Role { get; set; } = Role.None;
    public string Username { get; set; } = "";
}
